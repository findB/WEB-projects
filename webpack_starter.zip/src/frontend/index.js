'use strict';

if (module.hot) {
    module.hot.accept();
}

import '../styles/common.scss';
